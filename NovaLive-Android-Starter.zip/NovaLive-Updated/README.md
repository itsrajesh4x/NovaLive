# Nova Live — updated Android project

यह अपडेट आपके अपलोड किए गए `NovaLive-Complete-Update.zip` के मौजूदा Android प्रोजेक्ट पर आधारित है। मूल WebView UI, JavaScript bridge, Media3 player और channel import flow को बनाए रखते हुए फीचर जोड़े/सुधारे गए हैं।

## शामिल / लागू किए गए बदलाव

- M3U और M3U8 playlist import तथा tvg-id, logo और group-title parsing.
- JSON channel list import (`channels` या `data` array).
- Xtream Codes live-stream API import; username/password AndroidX EncryptedSharedPreferences में सुरक्षित.
- Direct HTTP(S) HLS/DASH stream URL import.
- एक से अधिक sources; add, edit, delete और individual refresh.
- source/channel cache और source credentials encrypted preferences में; app logs में credentials लिखने का code नहीं.
- Duplicate stream URL को merge करते समय हटाना.
- Favorites और Recent Channels; WebView local storage में URL के बजाय hashed channel key save होती है.
- XMLTV EPG parser: channel ID, title, description, start/end timestamps और timezone offset.
- TV Guide screen में वर्तमान/आगामी programme timeline; playlist `tvg-id` और XMLTV channel ID का match.
- EPG URL save, manual EPG load तथा WorkManager refresh के दौरान EPG cache refresh.
- WorkManager आधारित network-constrained automatic refresh; 1, 6, 12, 24, 48 घंटे या 1 सप्ताह.
- Last successful channel update समय, manual refresh और refresh status.
- Media3 ExoPlayer HLS/DASH modules, full-screen landscape player, play/pause controls, retry/error display, audio/subtitle track selector (जहाँ stream tracks उपलब्ध हों), lifecycle release.
- Premium dark UI, purple/cyan accents, launcher vector icon.
- GitHub Actions workflow: parser unit tests, Debug APK, Release APK और artifacts; version tag पर GitHub Release.

## Build — Android Studio

1. ZIP extract करें.
2. Android Studio में `NovaLive` folder खोलें (वही folder जिसमें `settings.gradle.kts` है).
3. Android SDK Platform 35 install रखें.
4. JDK 17 select करें; Gradle 8.9 compatible है.
5. Gradle Sync के बाद `app` > `Tasks` > `build` > `assembleDebug` चलाएँ.
6. Debug APK: `app/build/outputs/apk/debug/app-debug.apk`
7. Release build: `assembleRelease`. Signing secrets न होने पर output unsigned होगा: `app/build/outputs/apk/release/app-release-unsigned.apk`.

कमांड लाइन:
```bash
gradle --no-daemon testDebugUnitTest
gradle --no-daemon assembleDebug
gradle --no-daemon assembleRelease
```

## GitHub पर अपडेट upload करना

1. अपने GitHub repository `itsrajesh4x/NovaLive` को खोलें.
2. `Code` > `Add file` > `Upload files` चुनें.
3. इस ZIP को अपने कंप्यूटर/फोन में extract करें.
4. Extract किए हुए `NovaLive` project के अंदर की सभी files/folders repository के root में upload करें — root में `settings.gradle.kts`, `build.gradle.kts`, `app/`, `.github/` दिखने चाहिए.
5. पुरानी `.github/workflows/build.yml` को नई workflow से replace करें.
6. Commit changes करें. GitHub Actions में `Nova Live Android Build` workflow खुलेगा; build पूरा होने पर Artifacts से APK लें.

### Signed release APK के लिए GitHub Secrets

Repository > Settings > Secrets and variables > Actions में ये चार secrets बनाएँ:

- `KEYSTORE_BASE64` — अपने `.jks` keystore की Base64 सामग्री.
- `KEYSTORE_PASSWORD` — keystore password.
- `KEY_ALIAS` — key alias.
- `KEY_PASSWORD` — key password.

सभी चार secrets मौजूद होने पर signed release APK बनेगा; अन्यथा workflow unsigned release APK बनाएगा. Keystore या passwords को repository में commit न करें. GitHub Release बनाने के लिए `v1.2.0` जैसे version tag push करें.

## अभी की सीमाएँ / जरूरी test

- इस execution environment में Android SDK और Gradle executable उपलब्ध नहीं थे. इसलिए यहाँ Debug/Release APK build run नहीं हो सका. कोई APK इस ZIP के साथ शामिल नहीं है. GitHub Actions workflow build और parser tests चलाने के लिए तैयार किया गया है, लेकिन उसे चलाकर सफल परिणाम देखना बाकी है.
- Parser के लिए M3U, JSON और XMLTV unit tests जोड़े गए हैं; इस environment में वे execute नहीं हुए.
- Xtream API compatibility provider के response format पर निर्भर है. कुछ providers को category mapping या custom headers की जरूरत हो सकती है.
- DRM-protected streams, Widevine licence configuration, cookies/custom request headers और geo/auth bypass लागू नहीं हैं. App DRM या provider restrictions bypass नहीं करता.
- Recent channel history channel tap पर record होती है; player ने वास्तव में first frame render किया है, इसकी cross-activity confirmation अभी नहीं जोड़ी गई.
- Player में built-in Media3 controls और available tracks का selector है; dedicated next/previous channel overlay अभी नहीं है.
- UI में categories playlist के group-title/category fields से बनती हैं; कोई preloaded channel list या private stream URL शामिल नहीं है.
- HTTP URLs compatibility के लिए स्वीकार हैं. HTTP पर credentials/stream traffic encrypted नहीं होता; जहाँ संभव हो HTTPS URLs ही इस्तेमाल करें.
- EPG और channel refresh network availability तथा Android WorkManager scheduling पर निर्भर हैं; exact minute पर refresh की guarantee नहीं है.

**महत्वपूर्ण:** केवल वही playlists, Xtream credentials और streams जोड़ें जिनके उपयोग की आपको अनुमति है. इस project में कोई private/unauthorized channel endpoint शामिल नहीं किया गया है.
