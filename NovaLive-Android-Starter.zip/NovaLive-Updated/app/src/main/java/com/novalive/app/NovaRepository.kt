package com.novalive.app

import android.content.Context
import androidx.work.*
import org.json.JSONArray
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.TimeUnit

object NovaRepository {
    fun fetch(url: String): String {
        require(url.startsWith("https://") || url.startsWith("http://")) { "Only HTTP/HTTPS URLs are supported" }
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000; c.readTimeout = 25000
        c.setRequestProperty("User-Agent", "NovaLive/1.2")
        try {
            val code = c.responseCode
            if (code !in 200..299) throw IllegalStateException("Server returned HTTP $code")
            return c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally { c.disconnect() }
    }

    private fun field(o: JSONObject, vararg names: String): String {
        names.forEach { val v=o.optString(it, ""); if (v.isNotBlank() && v!="null") return v }
        return ""
    }

    fun parseSource(type: String, address: String, username: String = "", password: String = ""): JSONArray {
        return when(type.lowercase(Locale.ROOT)) {
            "direct" -> JSONArray().put(JSONObject().put("name","Direct stream").put("url",address).put("group","Direct").put("logo",""))
            "xtream" -> parseXtream(address, username, password)
            else -> parsePlaylist(fetch(address))
        }
    }

    fun parsePlaylist(raw: String): JSONArray {
        val t=raw.trim()
        if (t.startsWith("[") || t.startsWith("{")) {
            val arr = if(t.startsWith("[")) JSONArray(t) else {
                val root=JSONObject(t)
                (root.opt("channels") as? JSONArray) ?: (root.opt("data") as? JSONArray) ?: JSONArray()
            }
            val out=JSONArray()
            for(i in 0 until arr.length()) {
                val o=arr.optJSONObject(i) ?: continue
                val url=field(o,"url","stream_url","m3u8_url","mpd_url","channel_url","link")
                if(url.startsWith("http://") || url.startsWith("https://"))
                    out.put(JSONObject().put("name",field(o,"name","title","channel_name").ifBlank{"Channel ${i+1}"})
                        .put("url",url).put("group",field(o,"group","category","group_title").ifBlank{"Other"})
                        .put("logo",field(o,"logo","tvg_logo","icon")).put("tvgId",field(o,"tvg_id","tvgId")))
            }
            if(out.length()==0) throw IllegalArgumentException("JSON mein valid channel URL nahi mila")
            return out
        }
        val out=JSONArray(); var name="Channel"; var group="Other"; var logo=""; var tvgId=""
        t.lineSequence().forEach { line ->
            val s=line.trim()
            if(s.startsWith("#EXTINF",true)) {
                name=s.substringAfterLast(",").trim().ifBlank{"Channel"}
                group=Regex("group-title=['\"]([^'\"]*)['\"]",RegexOption.IGNORE_CASE).find(s)?.groupValues?.get(1)?:"Other"
                logo=Regex("tvg-logo=['\"]([^'\"]*)['\"]",RegexOption.IGNORE_CASE).find(s)?.groupValues?.get(1)?:""
                tvgId=Regex("tvg-id=['\"]([^'\"]*)['\"]",RegexOption.IGNORE_CASE).find(s)?.groupValues?.get(1)?:""
            } else if(s.startsWith("http://") || s.startsWith("https://")) {
                out.put(JSONObject().put("name",name).put("url",s).put("group",group).put("logo",logo).put("tvgId",tvgId))
                name="Channel"; group="Other"; logo=""; tvgId=""
            }
        }
        if(out.length()==0) throw IllegalArgumentException("Playlist mein koi valid M3U entry nahi mili")
        return out
    }

    private fun parseXtream(server:String,user:String,pass:String):JSONArray {
        require(user.isNotBlank() && pass.isNotBlank()) { "Xtream username aur password zaroori hain" }
        val base=server.trimEnd('/')
        val u=URLEncoder.encode(user,"UTF-8"); val p=URLEncoder.encode(pass,"UTF-8")
        val a=JSONArray(fetch("$base/player_api.php?username=$u&password=$p&action=get_live_streams"))
        val out=JSONArray()
        for(i in 0 until a.length()) {
            val o=a.optJSONObject(i) ?: continue
            val id=o.optString("stream_id","")
            if(id.isBlank()) continue
            val ext=o.optString("container_extension","m3u8").ifBlank{"m3u8"}
            out.put(JSONObject().put("name",o.optString("name","Channel"))
                .put("url","$base/live/$u/$p/$id.$ext")
                .put("group",o.optString("category_name","Live TV"))
                .put("logo",o.optString("stream_icon","")))
        }
        if(out.length()==0) throw IllegalArgumentException("Xtream API ne live channels return nahi kiye")
        return out
    }

    fun parseXmltv(xml: String): JSONArray {
        val out=JSONArray()
        val parser=XmlPullParserFactory.newInstance().newPullParser()
        parser.setInput(xml.reader())
        var event=parser.eventType
        while(event != XmlPullParser.END_DOCUMENT) {
            if(event==XmlPullParser.START_TAG && parser.name=="programme") {
                val channel=parser.getAttributeValue(null,"channel") ?: ""
                val start=parser.getAttributeValue(null,"start") ?: ""
                val stop=parser.getAttributeValue(null,"stop") ?: ""
                var title=""; var desc=""
                var e=parser.next()
                while(!(e==XmlPullParser.END_TAG && parser.name=="programme") && e!=XmlPullParser.END_DOCUMENT) {
                    if(e==XmlPullParser.START_TAG && parser.name=="title") title=parser.nextText()
                    else if(e==XmlPullParser.START_TAG && parser.name=="desc") desc=parser.nextText()
                    e=parser.next()
                }
                out.put(JSONObject().put("channelId",channel).put("start",xmltvTime(start))
                    .put("end",xmltvTime(stop)).put("title",title).put("description",desc))
            }
            event=parser.next()
        }
        return out
    }

    private fun xmltvTime(value:String):Long {
        if(value.isBlank()) return 0L
        val pattern=Regex("^(\\d{14})\\s*([+-]\\d{4})?")
        val m=pattern.find(value) ?: return 0L
        val tz=m.groupValues[2].ifBlank{"+0000"}
        val f=SimpleDateFormat("yyyyMMddHHmmss Z",Locale.US)
        f.isLenient=false
        return try { f.parse("${m.groupValues[1]} $tz")?.time ?: 0L } catch(_:Exception) { 0L }
    }

    fun schedule(context:Context, hours:Long) {
        val req=PeriodicWorkRequestBuilder<SourceRefreshWorker>(hours.coerceIn(1,168),TimeUnit.HOURS)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()).build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork("novalive-source-refresh",ExistingPeriodicWorkPolicy.UPDATE,req)
    }
}

class SourceRefreshWorker(ctx:Context, params:WorkerParameters):CoroutineWorker(ctx,params) {
    override suspend fun doWork():Result {
        return try {
            val prefs=applicationContext.getSharedPreferences("novalive",Context.MODE_PRIVATE)
            val key=androidx.security.crypto.MasterKey.Builder(applicationContext)
                .setKeyScheme(androidx.security.crypto.MasterKey.KeyScheme.AES256_GCM).build()
            val secure=androidx.security.crypto.EncryptedSharedPreferences.create(applicationContext,"novalive_secure",key,
                androidx.security.crypto.EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                androidx.security.crypto.EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM)
            val sources=JSONArray(secure.getString("sources","[]") ?: "[]")
            val merged=JSONArray()
            for(i in 0 until sources.length()) {
                val s=sources.optJSONObject(i) ?: continue
                val type=s.optString("type","m3u")
                val address=s.optString("address","")
                if(address.isBlank()) continue
                try {
                    val sid=s.optString("id")
                    val user=secure.getString("${sid}_user","") ?: ""
                    val pass=secure.getString("${sid}_pass","") ?: ""
                    val parsed=NovaRepository.parseSource(type,address,user,pass)
                    for(j in 0 until parsed.length()) {
                        val c=parsed.getJSONObject(j); c.put("sourceId",sid); merged.put(c)
                    }
                } catch(_:Exception) { /* keep the last known good cache on total failure */ }
            }
            val unique=JSONArray(); val seen=HashSet<String>()
            for(i in 0 until merged.length()) {
                val item=merged.optJSONObject(i) ?: continue
                if(seen.add(item.optString("url"))) unique.put(item)
            }
            val edit=prefs.edit()
            if(unique.length()>0) {
                secure.edit().putString("channels",unique.toString()).apply()
                edit.putLong("last_update",System.currentTimeMillis())
            }
            val epgUrl=prefs.getString("epg_url","") ?: ""
            if(epgUrl.isNotBlank()) {
                try {
                    val parsedEpg=NovaRepository.parseXmltv(NovaRepository.fetch(epgUrl))
                    edit.putString("epg_data",parsedEpg.toString()).putLong("epg_update",System.currentTimeMillis())
                } catch(_:Exception) { /* retain last good EPG cache */ }
            }
            edit.apply()
            Result.success()
        } catch(_:Exception) { Result.retry() }
    }
}
