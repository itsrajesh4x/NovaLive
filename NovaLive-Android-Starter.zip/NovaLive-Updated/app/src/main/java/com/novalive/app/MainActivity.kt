package com.novalive.app

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.webkit.*
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import androidx.work.WorkManager
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var web: WebView
    private val io=Executors.newFixedThreadPool(3)
    private val prefs by lazy { getSharedPreferences("novalive", MODE_PRIVATE) }
    private val secure by lazy {
        val key=MasterKey.Builder(this).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        EncryptedSharedPreferences.create(this,"novalive_secure",key,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM)
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState:Bundle?) {
        super.onCreate(savedInstanceState)
        web=WebView(this).apply {
            setBackgroundColor(0xff080914.toInt())
            settings.javaScriptEnabled=true
            settings.domStorageEnabled=true
            settings.allowFileAccess=true
            settings.allowContentAccess=false
            settings.mixedContentMode=WebSettings.MIXED_CONTENT_NEVER_ALLOW
            webViewClient=WebViewClient()
            addJavascriptInterface(Bridge(),"NovaAndroid")
        }
        setContentView(web); web.loadUrl("file:///android_asset/index.html")
    }

    inner class Bridge {
        @JavascriptInterface fun getSavedSources():String = secure.getString("sources","[]") ?: "[]"
        @JavascriptInterface fun getSavedChannels():String = secure.getString("channels","[]") ?: "[]"
        @JavascriptInterface fun getLastUpdate():String = prefs.getLong("last_update",0L).toString()
        @JavascriptInterface fun getSavedEpg():String = prefs.getString("epg_data","[]") ?: "[]"
        @JavascriptInterface fun saveEpgUrl(url:String) { prefs.edit().putString("epg_url",url).apply() }
        @JavascriptInterface fun getEpgUrl():String = prefs.getString("epg_url","") ?: ""
        @JavascriptInterface fun saveChannels(value:String) { secure.edit().putString("channels",value).apply() }
        @JavascriptInterface fun saveSources(value:String) { secure.edit().putString("sources",value).apply() }
        @JavascriptInterface fun getRefreshHours():String = prefs.getInt("refresh_hours",24).toString()
        @JavascriptInterface fun setRefreshHours(value:Int) {
            val h=value.coerceIn(1,168); prefs.edit().putInt("refresh_hours",h).apply()
            NovaRepository.schedule(this@MainActivity,h.toLong())
        }
        @JavascriptInterface fun scheduleRefresh() { NovaRepository.schedule(this@MainActivity,prefs.getInt("refresh_hours",24).toLong()) }
        @JavascriptInterface fun play(url:String,title:String) {
            runOnUiThread { startActivity(Intent(this@MainActivity,PlayerActivity::class.java).putExtra("url",url).putExtra("title",title)) }
        }
        @JavascriptInterface fun loadSource(type:String,address:String,username:String,password:String,id:String) {
            io.execute {
                try {
                    val result=NovaRepository.parseSource(type,address,username,password)
                    for(i in 0 until result.length()) result.getJSONObject(i).put("sourceId",id)
                    val payload=result.toString()
                    runOnUiThread { web.evaluateJavascript("window.onSourceLoaded(${JSONObject.quote(payload)},null)",null) }
                } catch(e:Exception) {
                    val msg=(e.message ?: "Source load failed").take(240)
                    runOnUiThread { web.evaluateJavascript("window.onSourceLoaded('[]',${JSONObject.quote(msg)})",null) }
                }
            }
        }
        @JavascriptInterface fun loadEpg(url:String) {
            io.execute {
                try {
                    val epg=NovaRepository.parseXmltv(NovaRepository.fetch(url)).toString()
                    prefs.edit().putString("epg_data",epg).putLong("epg_update",System.currentTimeMillis()).apply()
                    runOnUiThread { web.evaluateJavascript("window.onEpgLoaded(${JSONObject.quote(epg)},null)",null) }
                } catch(e:Exception) {
                    val msg=(e.message ?: "EPG unavailable").take(240)
                    runOnUiThread { web.evaluateJavascript("window.onEpgLoaded('[]',${JSONObject.quote(msg)})",null) }
                }
            }
        }
        @JavascriptInterface fun saveSecureSource(id:String,username:String,password:String) {
            secure.edit().putString("${id}_user",username).putString("${id}_pass",password).apply()
        }
        @JavascriptInterface fun getSecureSource(id:String):String {
            return JSONObject().put("username",secure.getString("${id}_user","") ?: "")
                .put("password",secure.getString("${id}_pass","") ?: "").toString()
        }
        @JavascriptInterface fun deleteSecureSource(id:String) {
            secure.edit().remove("${id}_user").remove("${id}_pass").apply()
        }
        @JavascriptInterface fun refreshNow() {
            io.execute {
                try {
                    val src=JSONArray(prefs.getString("sources","[]") ?: "[]")
                    val merged=JSONArray(); var errors=0
                    for(i in 0 until src.length()) {
                        val s=src.optJSONObject(i) ?: continue
                        try {
                            val secrets=JSONObject(getSecureSource(s.optString("id")))
                            val arr=NovaRepository.parseSource(s.optString("type"),s.optString("address"),
                                secrets.optString("username"),secrets.optString("password"))
                            for(j in 0 until arr.length()) { val c=arr.getJSONObject(j); c.put("sourceId",s.optString("id")); merged.put(c) }
                        } catch(_:Exception) { errors++ }
                    }
                    val unique=JSONArray(); val seen=HashSet<String>()
                    for(i in 0 until merged.length()) { val item=merged.optJSONObject(i) ?: continue; if(seen.add(item.optString("url"))) unique.put(item) }
                    if(unique.length()>0) { secure.edit().putString("channels",unique.toString()).apply(); prefs.edit().putLong("last_update",System.currentTimeMillis()).apply() }
                    val epgUrl=prefs.getString("epg_url","") ?: ""
                    if(epgUrl.isNotBlank()) try {
                        val epg=NovaRepository.parseXmltv(NovaRepository.fetch(epgUrl))
                        prefs.edit().putString("epg_data",epg.toString()).putLong("epg_update",System.currentTimeMillis()).apply()
                    } catch(_:Exception) { }
                    val msg=if(unique.length()==0) "No source could be refreshed" else "${unique.length()} channels updated${if (errors > 0) " ($errors source errors)" else ""}"
                    runOnUiThread { web.evaluateJavascript("window.onRefreshDone(${JSONObject.quote(msg)})",null) }
                } catch(e:Exception) { runOnUiThread { web.evaluateJavascript("window.onRefreshDone(${JSONObject.quote(e.message ?: "Refresh failed")})",null) } }
            }
        }
    }

    override fun onDestroy() { io.shutdown(); if(::web.isInitialized) web.destroy(); super.onDestroy() }
}
