package com.novalive.app

import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.ui.PlayerView

class PlayerActivity:ComponentActivity() {
    private var player:ExoPlayer?=null
    private lateinit var playerView:PlayerView
    private lateinit var errorBox:LinearLayout
    private var streamUrl=""
    private var channelTitle="Nova Live"

    override fun onCreate(savedInstanceState:Bundle?) {
        super.onCreate(savedInstanceState)
        streamUrl=intent.getStringExtra("url") ?: ""
        channelTitle=intent.getStringExtra("title") ?: "Nova Live"
        val root=FrameLayout(this).apply { setBackgroundColor(android.graphics.Color.BLACK) }
        playerView=PlayerView(this).apply { useController=true; controllerAutoShow=true; keepScreenOn=true }
        root.addView(playerView,FrameLayout.LayoutParams(-1,-1))
        errorBox=LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER
            setPadding(28,24,28,24); setBackgroundColor(0xdd101323.toInt()); visibility=View.GONE
        }
        val message=TextView(this).apply { setTextColor(-1); textSize=16f; text="Playback error" }
        val retry=Button(this).apply { text="Retry"; setOnClickListener { errorBox.visibility=View.GONE; startPlayback() } }
        errorBox.addView(message); errorBox.addView(retry)
        root.addView(errorBox,FrameLayout.LayoutParams(-1,-1))
        setContentView(root)
        hideSystemUi()
        if(streamUrl.isBlank()) showError("Stream URL missing") else startPlayback()
    }

    private fun hideSystemUi() {
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
            or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
    }
    override fun onWindowFocusChanged(hasFocus:Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if(hasFocus) hideSystemUi()
    }

    private fun startPlayback() {
        releasePlayer()
        val selector=DefaultTrackSelector(this)
        player=ExoPlayer.Builder(this).setTrackSelector(selector).build().also { p ->
            playerView.player=p
            p.addListener(object:Player.Listener {
                override fun onPlayerError(error:PlaybackException) {
                    showError("Playback failed: ${error.errorCodeName}\nStream offline, unsupported, or access denied.")
                }
            })
            p.setMediaItem(MediaItem.fromUri(streamUrl))
            p.prepare(); p.playWhenReady=true
        }
    }

    private fun showError(text:String) {
        errorBox.removeAllViews()
        errorBox.addView(TextView(this).apply { setTextColor(-1); textSize=16f; this.text=text; gravity=Gravity.CENTER })
        errorBox.addView(Button(this).apply { this.text="Retry"; setOnClickListener { errorBox.visibility=View.GONE; startPlayback() } })
        errorBox.visibility=View.VISIBLE
    }

    private fun releasePlayer() {
        playerView.player=null
        player?.release(); player=null
    }
    override fun onStop() { super.onStop(); player?.pause() }
    override fun onDestroy() { releasePlayer(); super.onDestroy() }
}
