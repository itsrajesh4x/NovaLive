package com.novalive.app

import org.json.JSONArray
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner

@RunWith(RobolectricTestRunner::class)
class NovaRepositoryTest {
    @Test fun parsesM3uEntriesAndMetadata() {
        val result=NovaRepository.parsePlaylist("""#EXTM3U
#EXTINF:-1 tvg-id="news.in" tvg-logo="https://example.org/logo.png" group-title="Hindi News",Demo News
https://example.org/live/news.m3u8
""")
        assertEquals(1,result.length())
        assertEquals("Demo News",result.getJSONObject(0).getString("name"))
        assertEquals("Hindi News",result.getJSONObject(0).getString("group"))
        assertEquals("news.in",result.getJSONObject(0).getString("tvgId"))
    }

    @Test fun parsesJsonChannels() {
        val result=NovaRepository.parsePlaylist("""{"channels":[{"name":"Demo","url":"https://example.org/live.mpd","category":"Sports"}]}""")
        assertEquals(1,result.length())
        assertEquals("Sports",result.getJSONObject(0).getString("group"))
        assertTrue(result.getJSONObject(0).getString("url").endsWith(".mpd"))
    }

    @Test fun rejectsMalformedOrEmptyPlaylist() {
        try {
            NovaRepository.parsePlaylist("#EXTM3U\n#EXTINF:-1,No URL")
            fail("Expected invalid playlist to be rejected")
        } catch(_:IllegalArgumentException) { }
    }

    @Test fun parsesXmltvProgrammeAndTimezone() {
        val xml="""<?xml version="1.0" encoding="UTF-8"?>
            <tv><programme channel="news.in" start="20261124180000 +0530" stop="20261124190000 +0530">
            <title lang="en">Evening News</title><desc>Daily bulletin</desc>
            </programme></tv>"""
        val result=NovaRepository.parseXmltv(xml)
        assertEquals(1,result.length())
        assertEquals("news.in",result.getJSONObject(0).getString("channelId"))
        assertEquals("Evening News",result.getJSONObject(0).getString("title"))
        assertEquals("Daily bulletin",result.getJSONObject(0).getString("description"))
        assertEquals(60*60*1000L,result.getJSONObject(0).getLong("end")-result.getJSONObject(0).getLong("start"))
    }
}
