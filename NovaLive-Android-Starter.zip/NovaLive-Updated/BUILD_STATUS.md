# Build verification status

- JavaScript syntax: checked with Node.js `--check` — passed.
- Android XML resources/manifest: parsed as well-formed XML — passed.
- Kotlin source: checked for Kotlin parser syntax diagnostics — none reported.
- Android Gradle Debug/Release builds: NOT RUN. This environment has no Gradle executable and no Android SDK.
- Added Robolectric unit tests for M3U, JSON and XMLTV parsing; NOT RUN here.
- No APK binaries are included because no successful Android build was performed.

Run the GitHub Actions workflow or build with Android Studio/JDK 17/SDK 35 to obtain and verify APK artifacts.
