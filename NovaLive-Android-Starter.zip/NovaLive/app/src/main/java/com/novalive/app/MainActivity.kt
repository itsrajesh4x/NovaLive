package com.novalive.app

import android.content.Intent
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = true
        web.webViewClient = WebViewClient()
        web.webChromeClient = WebChromeClient()
        web.addJavascriptInterface(NovaBridge(), "NovaAndroid")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    inner class NovaBridge {
        @JavascriptInterface
        fun playChannel(json: String) {
            runOnUiThread {
                val item = JSONObject(json)
                val intent = Intent(this@MainActivity, PlayerActivity::class.java)
                intent.putExtra("title", item.optString("name", "Live TV"))
                intent.putExtra("streamUrl", item.optString("url", ""))
                intent.putExtra("mimeType", item.optString("mimeType", ""))
                startActivity(intent)
            }
        }
    }

    @Deprecated("Deprecated in Android")
    override fun onBackPressed() {
        if (::web.isInitialized && web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
