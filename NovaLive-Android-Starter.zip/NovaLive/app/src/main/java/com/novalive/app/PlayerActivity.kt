package com.novalive.app

import android.os.Bundle
import android.view.View
import android.widget.TextView
import android.widget.FrameLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

class PlayerActivity : AppCompatActivity() {
    private var player: ExoPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility =
            (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        val title = intent.getStringExtra("title") ?: "Nova Live"
        val url = intent.getStringExtra("streamUrl").orEmpty()
        val mime = intent.getStringExtra("mimeType").orEmpty()

        val root = FrameLayout(this).apply { setBackgroundColor(0xFF000000.toInt()) }
        val playerView = PlayerView(this).apply { useController = true }
        root.addView(playerView, FrameLayout.LayoutParams(-1, -1))
        val label = TextView(this).apply {
            text = title
            textSize = 14f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(24, 18, 24, 18)
        }
        root.addView(label)
        setContentView(root)

        if (url.isBlank()) {
            label.text = "$title\nNo stream URL configured for this channel."
            return
        }

        player = ExoPlayer.Builder(this).build().also { exo ->
            playerView.player = exo
            val builder = MediaItem.Builder().setUri(url)
            if (mime.isNotBlank()) builder.setMimeType(mime)
            else if (url.contains(".m3u8", true)) builder.setMimeType(MimeTypes.APPLICATION_M3U8)
            exo.setMediaItem(builder.build())
            exo.prepare()
            exo.playWhenReady = true
        }
    }

    override fun onStop() {
        super.onStop()
        player?.release()
        player = null
    }
}
